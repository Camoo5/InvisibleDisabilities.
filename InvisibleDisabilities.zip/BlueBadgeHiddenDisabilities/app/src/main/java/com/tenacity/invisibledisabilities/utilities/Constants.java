package com.tenacity.invisibledisabilities.utilities;

public class Constants {
    /**
     * Constants used throughout the app.
     */
   public static final String DATABASE_NAME ="disabilites.db";
   public static final String DISABILITY_DATA_FILENAME = "disabilites.json";

}
