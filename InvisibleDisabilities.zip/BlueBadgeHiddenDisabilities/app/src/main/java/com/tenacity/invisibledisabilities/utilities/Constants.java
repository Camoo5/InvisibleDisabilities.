
package com.tenacity.invisibledisabilities.utilities;

/**
 * Constants used throughout the app.
 */
public class Constants {
    public static final String DATABASE_NAME = "invisible-db";
    public static final String DISABILITY_DATA_FILENAME = "disabilities.json";

}