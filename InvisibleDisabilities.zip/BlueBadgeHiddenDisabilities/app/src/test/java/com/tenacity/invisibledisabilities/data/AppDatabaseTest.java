package com.tenacity.invisibledisabilities.data;

import junit.framework.TestCase;

public class AppDatabaseTest extends TestCase {

}