package com.tenacity.hiddendisabilities.ui.gallery;

import junit.framework.TestCase;

public class DisabilityDetailFragmentTest extends TestCase {

}