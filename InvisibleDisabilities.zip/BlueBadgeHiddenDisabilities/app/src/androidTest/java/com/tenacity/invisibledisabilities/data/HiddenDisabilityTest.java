package com.tenacity.invisibledisabilities.data;

import junit.framework.TestCase;

public class HiddenDisabilityTest extends TestCase {

    public void testGetDisabilityId() {
    }

    public void testGetDisabilityDate() {
    }

    public void testGetHiddenDisabilityId() {
    }

    public void testSetHiddenDisabilityId() {
    }

    public void testTestToString() {
    }

    public void testTestEquals() {
    }

    public void testTestHashCode() {
    }

    public void testTestClone() {
    }
}